// Módulo: app/src/main/java/com/chicoeletro/dds/MainActivity.kt
// Descrição: Activity principal OFFLINE-FIRST. Sobe a UI e dispara UMA sync no startup (se houver internet),
// delegando a execução ao TrainingSyncViewModel.
// Autor: Valdinei Lankewicz
// Atualizado: 07/11/2025

package com.chicoeletro.dds

import android.Manifest
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import com.chicoeletro.dds.ui.sections.MainLayoutContainer
import com.chicoeletro.dds.ui.theme.DDSTheme
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser

import androidx.lifecycle.ViewModelProvider
import com.chicoeletro.dds.viewmodel.TrainingSyncViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class MainActivity : ComponentActivity() {

    // Activity Result API p/ permissões
    private val requestCameraPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* opcional */ }

    private val requestWriteLegacy =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* opcional */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val syncVM = ViewModelProvider(this)[TrainingSyncViewModel::class.java]

        // 1) Permissões
        requestRuntimePermissionsIfNeeded()

        ensureAuthenticated()

        // 2) UI
        setContent { DDSTheme { MainLayoutContainer() } }

        // 3) Sync no startup
        syncVM.startupSyncIfNeeded(hasInternet())


    }

    /**
     * Garante que sempre exista um usuário Firebase válido.
     *
     * - Se já houver usuário autenticado (Google ou anônimo), mantém.
     * - Se não houver, cria sessão anônima automaticamente.
     *
     * IMPORTANTE:
     * Este comportamento preserva o fluxo atual do app
     * e permite upgrade futuro (link anônimo → Google)
     * sem trocar UID nem quebrar relatórios existentes.
     */
    private fun ensureAuthenticated() {
        val auth = FirebaseAuth.getInstance()

        val currentUser: FirebaseUser? = auth.currentUser
        if (currentUser != null) {
            return
        }

        CoroutineScope(Dispatchers.IO).launch {
            auth.signInAnonymously()
                .addOnFailureListener { e ->
                    // Log apenas; não interrompe o app
                    android.util.Log.e(
                        "AUTH",
                        "Falha ao criar sessão anônima",
                        e
                    )
                }
        }
    }

    private fun requestRuntimePermissionsIfNeeded() {
        // CAMERA
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED
        ) {
            requestCameraPermission.launch(Manifest.permission.CAMERA)
        }
        // WRITE_EXTERNAL_STORAGE apenas até Android 9 (P)
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            requestWriteLegacy.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
    }

    /** Verifica conectividade VALIDADA. */
    private fun hasInternet(): Boolean = try {
        val cm = ContextCompat.getSystemService(this, ConnectivityManager::class.java) ?: return false
        val nw = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(nw) ?: return false
        caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    } catch (_: Exception) { false }
}
