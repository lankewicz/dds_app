// MÃ³dulo: app/src/main/java/com/chicoeletro/dds/features/team/TeamEditDialog.kt
// SOLUÇÃO DEFINITIVA: InputMethodManager direto + WindowInsetsCompat

package com.chicoeletro.dds.features.team

import android.app.Activity
import android.content.Context
import android.util.Log
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.KeyboardHide
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import java.util.Locale


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TeamEditDialog(
    initialTeamName: String,
    initialMembers: List<String>,
    mandatory: Boolean = false,
    onDismiss: () -> Unit,
    onSave: (teamName: String, members: List<String>) -> Unit,
) {
    BackHandler(enabled = true) { /* bloqueado: use os botões */ }

    val context = LocalContext.current

    // ═══════════════════════════════════════════════════════════════════════════════
    // IMPORTANTE: view capturado DENTRO do Dialog (não fora!)
    // ═══════════════════════════════════════════════════════════════════════════════

    val configuration = LocalConfiguration.current
    val serverClientId by remember(context, configuration) {
        mutableStateOf(
            runCatching {
                val resId = context.resources.getIdentifier(
                    "default_web_client_id",
                    "string",
                    context.packageName
                )
                if (resId == 0) "" else context.getString(resId)
            }.getOrDefault("")
        )
    }

    // Auth
    val auth = remember { FirebaseAuth.getInstance() }
    var currentUser by remember { mutableStateOf(auth.currentUser) }
    var isSigningIn by remember { mutableStateOf(false) }

    DisposableEffect(auth) {
        val listener = FirebaseAuth.AuthStateListener { fa -> currentUser = fa.currentUser }
        auth.addAuthStateListener(listener)
        onDispose { auth.removeAuthStateListener(listener) }
    }

    LaunchedEffect(currentUser) {
        if (currentUser == null) {
            auth.signInAnonymously()
                .addOnFailureListener { e ->
                    Log.e("AUTH", "Falha ao criar sessão anônima no TeamEditDialog", e)
                }
        }
    }

    val googleLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        isSigningIn = false
        if (result.resultCode != Activity.RESULT_OK) return@rememberLauncherForActivityResult

        val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
        try {
            val account: GoogleSignInAccount = task.getResult(ApiException::class.java)
            val idToken = account.idToken

            if (idToken.isNullOrBlank()) {
                Toast.makeText(context, "Falha ao obter token do Google", Toast.LENGTH_SHORT).show()
                return@rememberLauncherForActivityResult
            }

            val credential = GoogleAuthProvider.getCredential(idToken, null)
            val user = auth.currentUser

            if (user != null && user.isAnonymous) {
                user.linkWithCredential(credential)
                    .addOnSuccessListener {
                        Toast.makeText(context, "Conta Google vinculada com sucesso!", Toast.LENGTH_SHORT).show()
                    }
                    .addOnFailureListener { e ->
                        Log.e("AUTH", "Falha ao vincular conta Google", e)
                        Toast.makeText(context, "Falha ao vincular: ${e.message}", Toast.LENGTH_SHORT).show()
                    }
            } else {
                auth.signInWithCredential(credential)
                    .addOnSuccessListener {
                        Toast.makeText(context, "Login com Google realizado!", Toast.LENGTH_SHORT).show()
                    }
                    .addOnFailureListener { e ->
                        Log.e("AUTH", "Falha no login Google", e)
                        Toast.makeText(context, "Falha no login: ${e.message}", Toast.LENGTH_SHORT).show()
                    }
            }
        } catch (e: ApiException) {
            Log.e("AUTH", "Google Sign-In cancelado/erro", e)
            Toast.makeText(context, "Não foi possível autenticar com Google", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Log.e("AUTH", "Erro inesperado no Google Sign-In", e)
            Toast.makeText(context, "Erro inesperado ao autenticar", Toast.LENGTH_SHORT).show()
        }
    }

    fun startGoogleSignIn() {
        if (isSigningIn) return
        if (serverClientId.isBlank()) {
            Toast.makeText(context, "default_web_client_id não encontrado", Toast.LENGTH_LONG).show()
            return
        }
        isSigningIn = true

        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .requestIdToken(serverClientId)
            .build()

        val client = GoogleSignIn.getClient(context, gso)
        googleLauncher.launch(client.signInIntent)
    }

    // Estado do formulário
    val ptBr = remember { Locale("pt", "BR") }

    var teamName by remember { mutableStateOf(initialTeamName) }
    val members = remember {
        mutableStateListOf<String>().apply {
            addAll(initialMembers.filter { it.isNotBlank() })
            add("")
        }
    }

    fun normalizeTeamName(raw: String): String = raw.trim().uppercase(ptBr)
    fun normalizeMember(raw: String): String = raw.trim().uppercase(ptBr)

    fun normalizedMembers(): List<String> =
        members.map(::normalizeMember)
            .filter { it.isNotBlank() }
            .distinct()

    fun isTeamNameValid(name: String): Boolean {
        val teamTrimmed = name.trim()
        val upper = teamTrimmed.uppercase(ptBr)

        val minOk = teamTrimmed.length >= 5
        val maxOk = teamTrimmed.length <= 11
        val startsWithForbidden = listOf("CA", "PG", "LO", "MA", "CB").any { upper.startsWith(it) }
        val noSpacesOk = !teamTrimmed.contains(' ')
        val isAlphanumeric = teamTrimmed.all { it.isLetterOrDigit() }

        return minOk && maxOk && !startsWithForbidden && noSpacesOk && isAlphanumeric
    }

    val teamNameValid by remember(teamName) { derivedStateOf { isTeamNameValid(teamName) } }
    val canSave by remember(teamName, members) {
        derivedStateOf { teamName.trim().isNotBlank() && normalizedMembers().isNotEmpty() }
    }

    // ═══════════════════════════════════════════════════════════════════════════════
    // UI - Dialog
    // ═══════════════════════════════════════════════════════════════════════════════
    Dialog(
        onDismissRequest = { /* bloqueado */ },
        properties = DialogProperties(
            dismissOnClickOutside = false,
            dismissOnBackPress = false,
            usePlatformDefaultWidth = false
        )
    ) {
        // CAPTURA view AQUI DENTRO do Dialog (crucial!)
        val view = LocalView.current

        // ═══════════════════════════════════════════════════════════════════
        // FUNÇÃO QUE REALMENTE FUNCIONA (testada em Dialogs)
        // ═══════════════════════════════════════════════════════════════════
        fun hideKeyboard() {
            // Método 1: WindowInsetsCompat (mais moderno, funciona melhor em Dialogs)
            ViewCompat.getWindowInsetsController(view)?.hide(WindowInsetsCompat.Type.ime())

            // Método 2: InputMethodManager (fallback confiável)
            val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
            imm?.hideSoftInputFromWindow(view.windowToken, 0)

            // Método 3: Tentar na Activity também (alguns dispositivos precisam)
            val activity = context as? Activity
            activity?.currentFocus?.let { focusedView ->
                imm?.hideSoftInputFromWindow(focusedView.windowToken, 0)
            }

            // Post para re-executar após o frame (alguns IMEs atrasam)
            view.postDelayed({
                ViewCompat.getWindowInsetsController(view)?.hide(WindowInsetsCompat.Type.ime())
                imm?.hideSoftInputFromWindow(view.windowToken, 0)
            }, 100)

            Log.d("TeamEditDialog", "hideKeyboard executado")
        }

        Surface(
            shape = MaterialTheme.shapes.extraLarge,
            tonalElevation = 4.dp,
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .fillMaxHeight(0.80f)
                .pointerInput(Unit) {
                    detectTapGestures(onTap = { hideKeyboard() })
                }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(18.dp)
            ) {
                Text(
                    text = "Editar Equipe",
                    style = MaterialTheme.typography.headlineSmall
                )

                if (mandatory) {
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = "Cadastro obrigatório: informe a equipe e ao menos um participante para continuar.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(Modifier.height(12.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                        TeamCard(
                            teamName = teamName,
                            onTeamNameChange = { raw ->
                                teamName = raw.uppercase(ptBr).trimStart()
                            },
                            teamNameValid = teamNameValid,
                            currentUser = currentUser,
                            isSigningIn = isSigningIn,
                            onLoginClick = {
                                hideKeyboard()
                                startGoogleSignIn()
                            },
                            onDone = { hideKeyboard() }
                        )
                    }

                    Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                        ParticipantsCard(
                            members = members,
                            normalizedCount = normalizedMembers().size,
                            onHideKeyboard = { hideKeyboard() },
                            onAdd = {
                                if (members.isEmpty() || members.last().isNotBlank()) members.add("")
                            },
                            onClear = {
                                members.clear()
                                members.add("")
                            },
                            onMemberChange = { index, new ->
                                members[index] = new.uppercase(ptBr)
                                val filled = members.filter { it.trim().isNotBlank() }.toMutableList()
                                members.clear()
                                members.addAll(filled)
                                members.add("")
                            },
                            onRemove = { index ->
                                if (index in members.indices) {
                                    members.removeAt(index)
                                    if (members.isEmpty() || members.last().isNotBlank()) members.add("")
                                }
                            },
                            onDone = { hideKeyboard() }
                        )
                    }
                }

                Spacer(Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {

                    if (!mandatory) {
                        OutlinedButton(
                            onClick = {
                                hideKeyboard()
                                onDismiss()
                            },
                            modifier = Modifier.weight(1f)
                        ) { Text("Cancelar") }
                    }

                    Button(
                        onClick = {
                            hideKeyboard()
                            val team = normalizeTeamName(teamName)
                            val list = normalizedMembers()

                            if (team.isBlank() || list.isEmpty()) {
                                Toast.makeText(context, "Informe a equipe e pelo menos um participante", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            if (!isTeamNameValid(team)) {
                                Toast.makeText(context, "PREFIXO inválido (5-11; letras/números; sem espaços; não iniciar com CA/PG/LO/MA/CB).", Toast.LENGTH_SHORT).show()
                                return@Button
                            }

                            onSave(team, list)
                            Toast.makeText(context, "Equipe registrada com sucesso!", Toast.LENGTH_SHORT).show()
                            onDismiss()
                        },
                        enabled = canSave && teamNameValid,
                        modifier = Modifier.weight(1f)
                    ) { Text("Salvar") }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TeamCard(
    teamName: String,
    onTeamNameChange: (String) -> Unit,
    teamNameValid: Boolean,
    currentUser: com.google.firebase.auth.FirebaseUser?,
    isSigningIn: Boolean,
    onLoginClick: () -> Unit,
    onDone: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxSize(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Text("Equipe", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(10.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Identificação", style = MaterialTheme.typography.titleSmall)

                        val u = currentUser
                        when {
                            u == null -> {
                                Text("Usuário: carregando…", style = MaterialTheme.typography.bodySmall)
                                Text("Você pode entrar com Google para auditoria.", style = MaterialTheme.typography.bodySmall)
                            }
                            u.isAnonymous -> {
                                Text("Usuário: Anônimo", style = MaterialTheme.typography.bodySmall)
                                Text("Entre com Google para auditoria e sincronização.", style = MaterialTheme.typography.bodySmall)
                            }
                            else -> {
                                val name = u.displayName?.takeIf { it.isNotBlank() } ?: "Usuário Google"
                                val email = u.email?.takeIf { it.isNotBlank() } ?: "sem e-mail"
                                Text("Usuário: $name", style = MaterialTheme.typography.bodySmall)
                                Text("Conta: $email", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }

                    val showLogin = (currentUser == null || currentUser.isAnonymous)
                    if (showLogin) {
                        FilledTonalButton(
                            onClick = onLoginClick,
                            enabled = !isSigningIn
                        ) {
                            if (isSigningIn) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    strokeWidth = 2.dp
                                )
                                Spacer(Modifier.width(8.dp))
                            } else {
                                Icon(Icons.Default.VerifiedUser, contentDescription = null)
                                Spacer(Modifier.width(8.dp))
                            }
                            Text("Entrar")
                        }
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            OutlinedTextField(
                value = teamName,
                onValueChange = onTeamNameChange,
                label = { Text("Nome da Equipe") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                keyboardOptions = KeyboardOptions(
                    capitalization = KeyboardCapitalization.Characters,
                    imeAction = ImeAction.Done
                ),
                keyboardActions = KeyboardActions(
                    onDone = { onDone() }
                ),
                isError = teamName.isNotBlank() && !teamNameValid,
                supportingText = {
                    if (teamName.isNotBlank() && !teamNameValid) {
                        Text("PREFIXO inválido: 5-11 caracteres, letras/números, sem espaços, e não iniciar com CA/PG/LO/MA/CB.")
                    } else {
                        Text("Informe o prefixo da equipe (ex.: E3P01).")
                    }
                }
            )
        }
    }
}

@Composable
private fun ParticipantsCard(
    members: MutableList<String>,
    normalizedCount: Int,
    onHideKeyboard: () -> Unit,
    onAdd: () -> Unit,
    onClear: () -> Unit,
    onMemberChange: (index: Int, new: String) -> Unit,
    onRemove: (index: Int) -> Unit,
    onDone: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxSize(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Participantes", style = MaterialTheme.typography.titleMedium)

                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onHideKeyboard) {
                        Icon(Icons.Filled.KeyboardHide, contentDescription = "Ocultar teclado")
                    }

                    TextButton(onClick = onAdd) { Text("+ Adicionar") }
                    TextButton(onClick = onClear) { Text("Limpar") }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Total: $normalizedCount", style = MaterialTheme.typography.bodySmall)
                if (normalizedCount < 1) {
                    Text(
                        "Mínimo 1 participante!",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }

            Spacer(Modifier.height(10.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                members.forEachIndexed { index, value ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = value,
                            onValueChange = { new -> onMemberChange(index, new) },
                            label = { Text("Participante ${index + 1}") },
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(
                                capitalization = KeyboardCapitalization.Characters,
                                imeAction = ImeAction.Done
                            ),
                            keyboardActions = KeyboardActions(
                                onDone = { onDone() }
                            )
                        )

                        Spacer(Modifier.width(8.dp))

                        IconButton(onClick = { onRemove(index) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Remover")
                        }
                    }
                }
            }
        }
    }
}