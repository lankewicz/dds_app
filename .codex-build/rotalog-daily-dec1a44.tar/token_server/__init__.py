"""Token server module."""
